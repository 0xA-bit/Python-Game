print("Hello, welcome to logic riddles \n");

ans = input("Are you ready to play? (yes/no)\n")
score = 0
total_q = 4

if ans.lower() == "yes":
    ans = input("1. Alex is Charlie's father. Who of them was born later? \n")
    if ans.lower() == "charlie":
        score += 1
        print("Correct")
    else:
        print("Incorrect")

    ans = input("2. What is at the end of a rainbow? \n")
    if ans.lower() == "w":
        score += 1
        print("Correct")
    else:
        print("Incorrect")
            

    ans = input("3. What loses its head in the morning and gets it back at night? \n")
    if ans.lower() == "pillow":
        score += 1
        print("Correct")
    else:
        print("Incorrect")

    ans = input("4. A father's child, a mother's child, yet no one's son. Who am I?)? \n")
    if ans.lower() == "daughter":
        score += 1
        print("Correct")
    else:
        print("Incorrect")


    print("\n            Thankyou for playing, you got ", score, " questions correct. \n")
    mark = (score/total_q) * 100


    print("IQ Average: ", str(mark) + "%")
    
print("Keep it up!! ")
            



            

    




    
